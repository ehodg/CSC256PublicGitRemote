# CSC256PublicGitRemote
Wake Tech CSC256 public repo for working with GitHub 1st exercise
