def my_name_is():
    return "Eric Hodge"


# palaheel76 doesn't want any comments
def main():
    print(my_name_is())
